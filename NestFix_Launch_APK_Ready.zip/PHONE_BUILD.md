# NestFix — Build the Android APK from your phone

This project includes an EAS preview profile that outputs an installable APK.

## 1. Create the cloud build project

On your phone, open an Expo account and sign in to EAS from a browser or terminal environment.

If using an Android terminal such as Termux:

```bash
pkg update
pkg install nodejs-lts git
npm install -g eas-cli
```

Then extract this project and run:

```bash
cd NestFix_Launch_APK_Ready
npm install
npx eas login
npx eas build:configure
```

When EAS asks to configure the project, accept the Android project setup. EAS will generate the real `projectId`; do not invent one.

## 2. Configure Supabase

Create a Supabase project and run `supabase/schema.sql` in the SQL editor.
Create a private Storage bucket called `kyc-documents`.
Copy `.env.example` to `.env` and fill in the Supabase URL and anon key.

Never put a Supabase service-role key or payment secret in the mobile app.

For EAS cloud builds, add the same public Supabase values as EAS environment variables if the app is changed to use build-time variables. Secrets such as payment-provider keys must stay server-side.

## 3. Build an installable APK

```bash
npx eas build --platform android --profile preview
```

EAS will provide a build page and APK download link when the build finishes. Open the link on the Android phone and install the APK.

## 4. Production Play Store build

When the app has been tested:

```bash
npx eas build --platform android --profile production
```

The production profile creates an Android App Bundle for Play Store submission.

## Current launch limitations

- Payment provider credentials and server-side webhook verification still need to be connected.
- Remote push notifications need a server/Edge Function to send event notifications.
- Admin credentials must be created deliberately; the mobile client must never contain an admin/service-role secret.
- KYC bucket policies must be applied before accepting real identity documents.
