create extension if not exists pgcrypto;

create table if not exists profiles (
 id uuid primary key references auth.users(id) on delete cascade, full_name text, phone text,
 role text not null default 'customer' check (role in ('customer','professional','admin')), created_at timestamptz not null default now()
);
create table if not exists service_categories (id uuid primary key default gen_random_uuid(), name text unique not null, icon text, active boolean not null default true);
create table if not exists customer_locations (id uuid primary key default gen_random_uuid(), user_id uuid not null unique references profiles(id) on delete cascade, address text, latitude double precision, longitude double precision, updated_at timestamptz not null default now());
create table if not exists bookings (
 id uuid primary key default gen_random_uuid(), customer_id uuid not null references profiles(id) on delete cascade,
 professional_id uuid references profiles(id) on delete set null, service_type text not null, problem text not null,
 status text not null default 'requested' check (status in ('requested','matched','accepted','on_the_way','in_progress','completed','cancelled')),
 scheduled_at timestamptz, address text, latitude double precision, longitude double precision, estimated_price numeric, final_price numeric, created_at timestamptz not null default now()
);
create table if not exists professional_profiles (
 id uuid primary key references profiles(id) on delete cascade, business_name text, bio text, years_experience integer default 0,
 verification_status text not null default 'pending' check (verification_status in ('pending','verified','rejected')),
 service_area text, hourly_rate numeric, rating numeric not null default 0, jobs_completed integer not null default 0,
 available boolean not null default false, latitude double precision, longitude double precision,
 kyc_id_type text, kyc_id_last4 text, kyc_document_path text, verification_note text, submitted_at timestamptz
);
create table if not exists professional_services (professional_id uuid references professional_profiles(id) on delete cascade, service_name text not null, primary key (professional_id, service_name));
create table if not exists availability_slots (id uuid primary key default gen_random_uuid(), professional_id uuid references professional_profiles(id) on delete cascade, starts_at timestamptz not null, ends_at timestamptz not null, is_booked boolean not null default false);
create table if not exists device_tokens (id uuid primary key default gen_random_uuid(), user_id uuid not null references profiles(id) on delete cascade, token text not null, platform text not null default 'expo', created_at timestamptz not null default now(), unique(user_id,token));
create table if not exists payment_intents (id uuid primary key default gen_random_uuid(), booking_id uuid not null references bookings(id) on delete cascade, customer_id uuid not null references profiles(id) on delete cascade, amount numeric not null default 0, currency text not null default 'INR', provider text not null default 'external', provider_payment_id text, status text not null default 'pending' check(status in ('pending','authorized','paid','failed','refunded','cancelled')), created_at timestamptz not null default now());

alter table profiles enable row level security; alter table bookings enable row level security; alter table service_categories enable row level security; alter table professional_profiles enable row level security; alter table professional_services enable row level security; alter table availability_slots enable row level security; alter table customer_locations enable row level security; alter table device_tokens enable row level security; alter table payment_intents enable row level security;

create or replace function public.is_admin() returns boolean language sql security definer set search_path=public stable as $$ select exists(select 1 from public.profiles where id=auth.uid() and role='admin'); $$;
create or replace function public.distance_km(lat1 double precision, lon1 double precision, lat2 double precision, lon2 double precision) returns double precision language sql immutable as $$ select 6371 * 2 * asin(sqrt(power(sin(radians(lat2-lat1)/2),2) + cos(radians(lat1))*cos(radians(lat2))*power(sin(radians(lon2-lon1)/2),2))); $$;
create or replace function public.marketplace_search(p_service text, p_lat double precision default null, p_lon double precision default null, p_radius_km double precision default 25)
returns table(id uuid,business_name text,bio text,years_experience integer,service_area text,hourly_rate numeric,rating numeric,jobs_completed integer,available boolean,service_name text,distance_km double precision)
language sql security definer set search_path=public as $$
 select p.id,p.business_name,p.bio,p.years_experience,p.service_area,p.hourly_rate,p.rating,p.jobs_completed,p.available,ps.service_name,
 case when p_lat is not null and p_lon is not null and p.latitude is not null and p.longitude is not null then public.distance_km(p_lat,p_lon,p.latitude,p.longitude) else null end
 from professional_profiles p join professional_services ps on ps.professional_id=p.id
 where p.verification_status='verified' and p.available=true and ps.service_name=p_service
 and (p_lat is null or p_lon is null or p.latitude is null or p.longitude is null or public.distance_km(p_lat,p_lon,p.latitude,p.longitude)<=p_radius_km)
 order by case when p_lat is not null and p_lon is not null and p.latitude is not null and p.longitude is not null then public.distance_km(p_lat,p_lon,p.latitude,p.longitude) else 999999 end, p.rating desc;
$$;

create policy "users read own profile" on profiles for select using (auth.uid()=id or public.is_admin());
create policy "users update own profile" on profiles for update using (auth.uid()=id or public.is_admin()) with check (auth.uid()=id or public.is_admin());
create policy "users insert own profile" on profiles for insert with check (auth.uid()=id);
create policy "booking participants read" on bookings for select using (auth.uid()=customer_id or auth.uid()=professional_id or public.is_admin());
create policy "customers create bookings" on bookings for insert with check (auth.uid()=customer_id);
create policy "booking participants can update" on bookings for update using (auth.uid()=customer_id or auth.uid()=professional_id or public.is_admin()) with check (auth.uid()=customer_id or auth.uid()=professional_id or public.is_admin());
create policy "public read active services" on service_categories for select using (active=true);
insert into service_categories(name,icon) values ('Plumbing','💧'),('Electrician','⚡'),('AC Repair','❄️'),('Cleaning','🧹'),('Painting','🎨'),('Carpenter','🪚'),('Construction','🧱'),('Appliance','🔧') on conflict (name) do nothing;
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id, role) values (new.id, case when new.raw_user_meta_data->>'role'='professional' then 'professional' else 'customer' end) on conflict (id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users; create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
create policy "public can view verified professionals" on professional_profiles for select using (verification_status='verified' or auth.uid()=id or public.is_admin());
create policy "professionals manage own profile" on professional_profiles for all using (auth.uid()=id or public.is_admin()) with check (auth.uid()=id or public.is_admin());
create policy "public can view professional services" on professional_services for select using (true);
create policy "professionals manage own services" on professional_services for all using (auth.uid()=professional_id or public.is_admin()) with check (auth.uid()=professional_id or public.is_admin());
create policy "public can view available slots" on availability_slots for select using (is_booked=false or auth.uid()=professional_id or public.is_admin());
create policy "professionals manage own slots" on availability_slots for all using (auth.uid()=professional_id or public.is_admin()) with check (auth.uid()=professional_id or public.is_admin());
create policy "users manage own location" on customer_locations for all using (auth.uid()=user_id or public.is_admin()) with check (auth.uid()=user_id or public.is_admin());
create policy "users manage own tokens" on device_tokens for all using (auth.uid()=user_id or public.is_admin()) with check (auth.uid()=user_id or public.is_admin());
create policy "customers read own payments" on payment_intents for select using (auth.uid()=customer_id or public.is_admin());
create policy "customers create own payments" on payment_intents for insert with check (auth.uid()=customer_id);
create policy "admins update payments" on payment_intents for update using (public.is_admin()) with check (public.is_admin());
create or replace view public.marketplace_professionals as select p.id,p.business_name,p.bio,p.years_experience,p.service_area,p.hourly_rate,p.rating,p.jobs_completed,p.available,ps.service_name from professional_profiles p join professional_services ps on ps.professional_id=p.id where p.verification_status='verified' and p.available=true;

-- Storage: create a private bucket named kyc-documents in Supabase Storage.
-- Then add these Storage policies in the Supabase dashboard if your project does not auto-create them:
-- 1) authenticated users may INSERT objects only under their own user-id folder.
-- 2) users may SELECT their own KYC objects; admins may SELECT all KYC objects.
-- Keep this bucket private; never make government-ID documents public.
-- Promote your own admin user after signup with: update public.profiles set role='admin' where id='YOUR_AUTH_USER_UUID';
