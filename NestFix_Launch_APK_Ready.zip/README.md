# NestFix Launch MVP

This build adds the launch layer to the NestFix marketplace:

- Customer service address + GPS location capture
- Local professional matching
- Professional KYC document upload to a private Supabase Storage bucket
- Admin KYC/verification visibility
- Device notification token registration + local notification hooks
- Payment-intent records with an external-provider adapter point (no fake payment credentials)
- Existing customer/professional/admin marketplace and job workflow

## Run

```bash
npm install
npx expo start
```

## Supabase setup

1. Create a Supabase project.
2. Run `supabase/schema.sql` in the SQL editor.
3. Create a **private** Storage bucket named `kyc-documents`.
4. Add Storage policies so authenticated professionals can upload/read only their own folder and admins can read KYC documents.
5. Put the project URL and anon key in `.env` using `.env.example`.
6. Create a normal account and promote its profile to admin using the SQL comment at the bottom of the schema.

## Payments

The app creates a `payment_intents` record and deliberately does not claim that money has been collected. Connect a real payment provider on the server side (for example through a secure Edge Function) and update the payment intent after provider confirmation/webhook verification.

## Notifications

The app registers Expo push tokens when permission is granted and uses local notifications for immediate device feedback. For production remote notifications, add a server/Edge Function that reads `device_tokens` and sends authenticated notifications after booking/job events.

## APK

This project is prepared for an Expo cloud Android build. An Android developer account and project/build credentials are still required to generate a distributable APK/AAB.
